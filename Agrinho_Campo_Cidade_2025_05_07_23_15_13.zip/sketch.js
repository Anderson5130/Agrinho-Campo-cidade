let carroX, solY, nuvensX;

function setup() {
  createCanvas(600, 400);
  carroX = width; // Carro começa fora da tela
  solY = 60; // Posição inicial do sol
  nuvensX = 0; // Movendo as nuvens
}

function draw() {
  background(135, 206, 250); // Céu azul

  // Sol (movimento suave de oscilação)
  fill(255, 204, 0);
  ellipse(500, solY, 80, 80);
  solY += sin(frameCount * 0.02) * 0.5;

  // Nuvens (movimento contínuo)
  fill(255);
  for (let i = 0; i < 3; i++) {
    ellipse(nuvensX + 150 + i * 100, 80 - i * 10, 60, 40);
    ellipse(nuvensX + 180 + i * 100, 90 - i * 10, 50, 30);
  }
  nuvensX += 1;
  if (nuvensX > width) nuvensX = -150;

  // Campo à esquerda
  fill(34, 139, 34);
  rect(0, 200, width / 2, 200);

  // Múltiplas árvores no campo
  for (let i = 50; i < 250; i += 60) {
    fill(139, 69, 19);
    rect(i, 250, 20, 50);
    fill(34, 139, 34);
    ellipse(i + 10, 220, 80, 80);
    ellipse(i - 20, 210, 60, 60);
    ellipse(i + 40, 210, 60, 60);
  }

  // Casa de fazenda
  fill(210, 180, 140);
  rect(50, 270, 80, 50);
  fill(139, 0, 0);
  triangle(50, 270, 130, 270, 90, 230);
  fill(255);
  rect(65, 285, 20, 20);
  rect(100, 285, 20, 20);
  fill(0);
  rect(85, 310, 15, 20);

  // Cidade à direita
  fill(128, 128, 128);
  rect(width / 2, 200, width / 2, 200);

  // Prédios estilizados
  fill(100);
  rect(320, 150, 80, 130);
  rect(450, 100, 80, 180);

  // Janelas
  fill(255);
  for (let i = 330; i < 390; i += 20) {
    for (let j = 160; j < 270; j += 20) {
      rect(i, j, 12, 12);
    }
  }
  for (let i = 460; i < 520; i += 20) {
    for (let j = 110; j < 270; j += 20) {
      rect(i, j, 12, 12);
    }
  }

  // Semáforo
  fill(50);
  rect(410, 280, 10, 40);
  let luz = frameCount % 180 < 60 ? [255, 0, 0] : frameCount % 180 < 120 ? [255, 255, 0] : [0, 255, 0];
  fill(luz);
  ellipse(415, 290, 10, 10);
  fill(255, 255, 0);
  ellipse(415, 300, 10, 10);
  fill(0, 255, 0);
  ellipse(415, 310, 10, 10);

  // Estrada
  fill(50);
  rect(300, 350, 300, 30);
  fill(255, 255, 0);
  for (let i = 310; i < 580; i += 40) {
    rect(i, 365, 20, 5);
  }

  // Carro animado
  fill(200, 0, 0);
  rect(carroX, 330, 60, 30);
  fill(0);
  ellipse(carroX + 10, 360, 15, 15);
  ellipse(carroX + 50, 360, 15, 15);
  fill(255);
  rect(carroX + 10, 335, 30, 10);

  carroX -= 2; // Movimento da direita para a esquerda
  if (carroX < -60) carroX = width; // Reinicia ao sair da tela
}
